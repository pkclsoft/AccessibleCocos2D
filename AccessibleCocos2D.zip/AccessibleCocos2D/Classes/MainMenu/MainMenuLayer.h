//
//  MainMenuLayer.h
//  AccessibleCocos2D
//
//  Created by Peter Easdown on 8/10/13.
//  Copyright 2014 PKCLsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MainMenuLayer : CCLayer

+ (MainMenuLayer*) sharedInstance;

@end
