//
//  CCMenuItem+CCSwitchableNode.h
//  AccessibleCocos2D
//
//  Created by Peter Easdown on 11/06/2014.
//  Copyright (c) 2014 PKCLsoft. All rights reserved.
//

#import "CCMenuItem.h"
#import "CCSwitchableNode.h"

@interface CCMenuItem (CCSwitchableNode) <CCSwitchableNode>

@end
