//
//  CCNode+Util.h
//  AccessibleCocos2D
//
//  Created by Peter Easdown on 4/11/2013.
//  Copyright (c) 2014 PKCLsoft. All rights reserved.
//

#import "CCNode.h"

@interface CCNode (Util)

- (CGPoint) centre;

@end
