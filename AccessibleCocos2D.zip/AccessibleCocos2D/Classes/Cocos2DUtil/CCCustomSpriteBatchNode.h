//
//  CCCustomSpriteBatchNode.h
//  AccessibleCocos2D
//
//  Created by Peter Easdown on 29/03/13.
//  Copyright 2014 PKCLsoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface CCCustomSpriteBatchNode : CCSpriteBatchNode {
    
}

@end
